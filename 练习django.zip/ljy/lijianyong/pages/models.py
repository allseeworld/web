from django.db import models


# Create your models here.

class Shop(models.Model):
    kind = models.CharField(max_length=64)
    img = models.CharField(max_length=156)
