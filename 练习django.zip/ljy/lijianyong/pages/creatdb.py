import os


# def creatdb():
#     path = 'C:/Users/14563/Desktop/lijianyong/lijianyong/static/images2'
#     filer = os.