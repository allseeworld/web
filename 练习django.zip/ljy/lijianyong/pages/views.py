from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from rest_framework.response import Response

# from pages.models import Shop
from .myfunction import indexss


def index(request):
    phone_number = request.session.get('phone_number')
    from .models import Shop
    return render(request, 'login.html', context=indexss(Shop,phone_number))





