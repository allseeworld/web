


def indexss(Shop,phone_number=False):
    shop = Shop.objects.all()
    dictss = {'1': [], '2': [], '3': [], '4': [], '5': [], '6': [],'7':[]}
    for i in shop:
        dictss[i.kind].append(i.img)
    if phone_number:
        dictss['number'] = phone_number
    return dictss
