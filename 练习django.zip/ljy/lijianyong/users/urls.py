from django.conf.urls import url

# from  import views
from . import views

urlpatterns = [
    url(r'^loginy/', views.LoginYan.as_view(), name='loginy'),
    url(r'^loginout/', views.LoginYan.as_view(), name='loginout'),
    url(r'^login/', views.login, name='login'),
    url(r'^register/', views.register, name='register'),
    url(r'^yangzheng/', views.Yan.as_view(), name='yangzheng'),

]
