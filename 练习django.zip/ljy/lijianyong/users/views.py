import re

from django.shortcuts import render

# Create your views here.
from requests import Request
from rest_framework.views import APIView

# from pages.myfunction import indexss
# from .myfunction import indexss
# from lijianyong.pages.models import Shop
# from lijianyong.pages.models import Shop
# from lijianyong.pages.models import Shop
# from pages.models import Shop
# from lijianyong.pages.models import Shop
from lijianyong.pages.models import Shop
from lijianyong.users.myfunction import indexss
from .models import User

#
# def indexss(shop, phone_number=False):
#     dictss = {1: [], 2: [], 3: [], 4: [], 5: [], 6: [], '7': [], '8': []}
#     for i in shop:
#         dictss[i.kind].append(i.img)
#     if phone_number:
#         dictss['number'] = phone_number
#     return dictss


def login(request):
    phone_number = request.session.get('phone_number')
    # from lijianyong.pages.models import Shop
    shop = Shop.object.all()
    return render(request, 'login.html', context=indexss(shop, phone_number))


def register(request):
    return render(request, 'register.html')


class Yan(APIView):
    def post(self, request):
        data = request.data
        print(data)
        p = {}
        phone_number = data['phone_number']
        print('ph', phone_number)
        phone_number1 = re.findall(r"^1[34578]\d{9}$", phone_number)
        if not phone_number1:
            return render(request, 'cuw.html', context={'message': '电话号码有误'})
        password1 = data['password1']
        password2 = data['password2']
        print('pa', password1)
        if password1 != password2:
            return render(request, 'cuw.html', context={'message': '密码错误'})
        email = data['email']
        email1 = re.findall(r'[0-9A-Za-z][0-9A-Za-z_]+@[0-9A-Za-z_]+\.[conm]+', email)
        print('e', email1)
        if not email1 and 10 < len(email) <= 150:
            return render(request, 'cuw.html', context={'message': '邮箱有误'})
        user = User.objects.filter(phone_number=phone_number).first()
        if user:
            return render(request, 'cuw.html', context={'message': '用户名已存在'})
        password1 = request.a
        User.objects.create(email=email1, phone_number=phone_number, password=password1)
        return render(request, 'login.html')


class LoginYan(APIView):
    def get(self, request):
        request.session.flush()
        phone_number = []
        # from lijianyong.pages.models import Shop
        shop = Shop.object.all()
        return render(request, 'index.html', context=indexss(shop))

    def post(self, request):
        data = request.data
        phone_number = data['phone_number']
        print('ph', phone_number)
        phone_number1 = re.findall(r"^1[34578]\d{9}$", phone_number)
        if not phone_number1:
            return render(request, 'cuw.html', context={'message': '电话号码有误'})
        password1 = data['password']
        user = User.objects.filter(phone_number=phone_number).filter(password=password1).first()
        request.session['phone_number'] = user.phone_number
        shop = Shop.object.all()
        # from lijianyong.pages.models import Shop
        return render(request, 'index.html', context=indexss(shop, phone_number))
